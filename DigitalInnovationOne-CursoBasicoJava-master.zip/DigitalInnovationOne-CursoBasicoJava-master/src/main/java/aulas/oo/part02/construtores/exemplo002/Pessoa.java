package aulas.oo.part02.construtores.exemplo002;

public class Pessoa {

    private String nome;

    public Pessoa() {
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
}
