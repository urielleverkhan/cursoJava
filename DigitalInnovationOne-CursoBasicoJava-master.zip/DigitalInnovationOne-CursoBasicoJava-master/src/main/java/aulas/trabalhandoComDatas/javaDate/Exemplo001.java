package aulas.trabalhandoComDatas.javaDate;

import java.util.Date;

/**
 * Exemplo de utilização do construtor padrão da classe Date
 */
public class Exemplo001 {

    public static void main(String[] args) {

        Date novaData = new Date();

        System.out.println(novaData);

    }

}
